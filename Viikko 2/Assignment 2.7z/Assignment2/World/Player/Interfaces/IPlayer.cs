﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment2.World
{
    class IPlayer
    {

        int Score { get; set; }




    }
}
